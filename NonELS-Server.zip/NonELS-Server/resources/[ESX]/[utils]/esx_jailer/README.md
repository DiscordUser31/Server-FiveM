# esx_jailer
#pour Linstant en developpement


Pouvoir mettre les pesonnes en cellule que pour les policiers


/unjail id          
-->faire sortir la personne de la prison


/jail1 id sec       
-->Mettre la personne dans cellule 1


/jail2 id sec       
-->Mettre la personne dans cellule 2


/jail3 id sec       
-->Mettre la personne dans cellule 3
