# fxserver-esx_animations
FXServer ESX Animations

[INSTALLATION]

1) CD in your resources/[esx] folder
2) Clone the repository
```
git clone https://github.com/FXServer-ESX/fxserver-esx_animations esx_animations
```
3) Add this in your server.cfg :

```
start esx_animations
```
