Hey everyone! After a bunch of developing, testers testing, and having fun with this project I am proud to announce its release. https://discord.gg/yQpk5d2

Here is just some quick information on how to setup traffic advisers for your vehicles BEFORE the installation begins.


**Default Controls**

(Keyboard)
* Q - Up 1 light stage
* LCTRL + Q - Down 1 Light Stage
* 1, 2, 3 - 3 siren tons
* 4 - Enable/disable dual siren
* 5,6,7 - With duals on will sound another siren
* LCTRL + T - Takedown lights
* Y - Up 1 pattern for primary
* U - Up 1 pattern for secondary
* L - Up 1 for traffic adviser
* LCTRL + Y - Down 1 pattern for primary
* LCTRL + U - Down 1 pattern for secondary
* LCTRL + L - Down 1 for traffic adviser

(Controller)

* B - Up 1 stage
* A + B - Down 1 Stage
* DPAD Down - Siren Tone 1
* DPAD Left - Siren Tone 2
* DPAD Up - Siren Tone 3
* LS - Horn
* A + DPAD Right - Takedowns
* A + LS - Enable/Disable Dual Siren
* A + DPAD Down - Dual Siren 1
* A + DPAD Left- Dual Siren 2
* A + DPAD Up - Dual Siren 3

**Installation Guide**
https://youtu.be/5-NGCLjew64


**Download**
https://mrdagree.com/download/els-fivem



**Agreement**
You are not to release any form of edits of this script, none are allowed. You are welcome to edit and make any changes you wish for said community, server, persons, not for release or to be given anywhere else. You may not claim this as your own, this is my work. If you take anything from this script to use for another script, you must include me in the credits. If I see any form of releases that are edited versions you will be asked to take it down. Any major edits, new features, fixes, etc may be sent to me for review and be added to an official release.