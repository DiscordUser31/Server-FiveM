version '1.0.1'

client_scripts {
	'config.lua',
	'client.lua',
}

server_scripts {
	'server.lua',
}
