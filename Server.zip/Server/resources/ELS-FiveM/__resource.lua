description "ELS FiveM" -- Resource Descrption

client_script {
	'client/patterns.lua',
	'client/client.lua',
	'config.lua',
}

server_script {
	'server/server.lua',
	'server/xml.lua',
	'config.lua',
}