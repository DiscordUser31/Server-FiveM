Pouvoir mettre de personnes en cellule. La commance n'est que accessible par les policiers.
Dans le server.lue tu sais changer les secondes par défault et le max de secondes qu'une personne peut rester en prison.

Commandes en chat (T):
Pouvoir mettre les pesonnes en cellule que pour les policiers

/unjail id
-->faire sortir la personne de la prison

/jail1 id sec
-->Mettre la personne dans cellule 1

/jail2 id sec
-->Mettre la personne dans cellule 2

/jail3 id sec
-->Mettre la personne dans cellule 3
