# fxserver-esx_sit

This script allow you to sit almost everywhere.
If the player has many props around him, the game camera might become crazy.

[INSTALLATION]

1) CD in your resources/[esx] folder
2) Clone the repository
```
git clone https://github.com/FXServer-ESX/fxserver-esx_sit esx_sit
```
3) Add this in your server.cfg :
```
start esx_sit
```
[CREDITS]

- Original code by CmJustice https://github.com/CmJustice